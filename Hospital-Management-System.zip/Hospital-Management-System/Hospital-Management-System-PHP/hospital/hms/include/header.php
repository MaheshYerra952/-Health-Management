<?php error_reporting(0);?>
<header class="navbar navbar-default navbar-static-top" style="background: #fff; border: none; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
					<!-- start: NAVBAR HEADER -->
					<div class="navbar-header">
						<a href="#" class="sidebar-mobile-toggler pull-left hidden-md hidden-lg" class="btn btn-navbar sidebar-toggle" data-toggle-class="app-slide-off" data-toggle-target="#app" data-toggle-click-outside="#sidebar">
							<i class="ti-align-justify" style="color: #34495e;"></i>
						</a>
						<a class="navbar-brand" href="#" style="padding: 15px;">
							<h2 style="color: #34495e; margin: 0; font-weight: 600; letter-spacing: 1px;">HMS</h2>
						</a>
						<a href="#" class="sidebar-toggler pull-right visible-md visible-lg" data-toggle-class="app-sidebar-closed" data-toggle-target="#app">
							<i class="ti-align-justify" style="color: #34495e;"></i>
						</a>
						<a class="pull-right menu-toggler visible-xs-block" id="menu-toggler" data-toggle="collapse" href=".navbar-collapse">
							<span class="sr-only">Toggle navigation</span>
							<i class="ti-view-grid" style="color: #34495e;"></i>
						</a>
					</div>
					<!-- end: NAVBAR HEADER -->
					<!-- start: NAVBAR COLLAPSE -->
					<div class="navbar-collapse collapse">
						<ul class="nav navbar-right">
							<!-- start: MESSAGES DROPDOWN -->
								<li style="padding: 15px;">
								<h2 style="color: #2c3e50; margin: 0; font-size: 1.5em; font-weight: 500;">Hospital Management System</h2>
							</li>
						
						
							<li class="dropdown current-user">
								<a href class="dropdown-toggle" data-toggle="dropdown" style="padding: 15px; display: flex; align-items: center;">
									<div class="profile-image-container" style="position: relative;">
										<img src="assets/images/images.jpg" style="width: 40px; height: 40px; border-radius: 50%; border: 2px solid #95a5a6; object-fit: cover;"> 
									</div>
									<div class="user-info" style="margin-left: 12px; text-align: left;">
										<span class="username" style="color: #2c3e50; font-size: 14px; font-weight: 600; display: block;">
											<?php 
											$query=mysqli_query($con,"select fullName from users where id='".$_SESSION['id']."'");
											while($row=mysqli_fetch_array($query)) {
												echo $row['fullName'];
											}
											?>
										</span>
									</div>
									<i class="ti-angle-down" style="color: #34495e; margin-left: 8px;"></i>
								</a>
								<ul class="dropdown-menu dropdown-dark" style="border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); width: 220px; padding: 10px 0; background: #fff;">
									<li>
										<a href="edit-profile.php" style="padding: 12px 20px; display: flex; align-items: center;">
											<i class="fa fa-user" style="margin-right: 12px; color: #34495e; width: 20px; text-align: center;"></i> 
											<span style="color: #2c3e50;">My Profile</span>
										</a>
									</li>
									<li>
										<a href="change-password.php" style="padding: 12px 20px; display: flex; align-items: center;">
											<i class="fa fa-key" style="margin-right: 12px; color: #34495e; width: 20px; text-align: center;"></i> 
											<span style="color: #2c3e50;">Change Password</span>
										</a>
									</li>
									<li style="border-top: 1px solid #eee; margin-top: 5px;">
										<a href="logout.php" style="padding: 12px 20px; display: flex; align-items: center;">
											<i class="fa fa-sign-out" style="margin-right: 12px; color: #e74c3c; width: 20px; text-align: center;"></i> 
											<span style="color: #2c3e50;">Log Out</span>
										</a>
									</li>
								</ul>
							</li>
							<!-- end: USER OPTIONS DROPDOWN -->
						</ul>
						<!-- start: MENU TOGGLER FOR MOBILE DEVICES -->
						<div class="close-handle visible-xs-block menu-toggler" data-toggle="collapse" href=".navbar-collapse">
							<div class="arrow-left"></div>
							<div class="arrow-right"></div>
						</div>
						<!-- end: MENU TOGGLER FOR MOBILE DEVICES -->
					</div>
				
					
					<!-- end: NAVBAR COLLAPSE -->
				</header>

<style>
    .navbar-default {
        background-color: #fff;
        border-color: transparent;
    }
    .dropdown-menu {
        background-color: white;
        border: none;
    }
    .dropdown-menu > li > a {
        color: #2c3e50;
        transition: all 0.3s ease;
        font-size: 14px;
    }
    .dropdown-menu > li > a:hover {
        background-color: #f8f9fa;
        color: #34495e;
    }
    .navbar-right {
        margin-right: 0;
    }
    .current-user .dropdown-toggle {
        display: flex;
        align-items: center;
        transition: all 0.3s ease;
    }
    .current-user .dropdown-toggle:hover {
        background-color: #f8f9fa;
    }
    .current-user .username {
        font-weight: 600;
    }
    @media (max-width: 768px) {
        .navbar-brand h2 {
            font-size: 1.5em;
        }
        .navbar-right li h2 {
            font-size: 1.2em;
        }
        .user-info {
            display: none;
        }
        .current-user .dropdown-toggle {
            padding: 10px;
        }
    }
</style>
