<?php
session_start();
include('include/config.php');
if(!isset($_SESSION['id']))
{
    header('location:logout.php');
}
else
{
    $pid = $_SESSION['id'];
    $query = mysqli_query($con, "SELECT * FROM patients WHERE id='$pid'");
    $patient = mysqli_fetch_array($query);
    
    // Get appointment count
    $appointmentQuery = mysqli_query($con, "SELECT COUNT(*) as total FROM appointment WHERE patientId='$pid'");
    $appointmentCount = mysqli_fetch_array($appointmentQuery)['total'];
    
    // Get confirmed appointments count
    $confirmedQuery = mysqli_query($con, "SELECT COUNT(*) as total FROM appointment WHERE patientId='$pid' AND userStatus=1");
    $confirmedCount = mysqli_fetch_array($confirmedQuery)['total'];
    
    // Get pending appointments count
    $pendingQuery = mysqli_query($con, "SELECT COUNT(*) as total FROM appointment WHERE patientId='$pid' AND userStatus=0");
    $pendingCount = mysqli_fetch_array($pendingQuery)['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Patient Dashboard | HMS</title>
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
    <link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
</head>

<body>
    <div id="app">
        <div class="app-content">
            <div class="main-content">
                <div class="wrap-content container" id="container">
                    <div class="patients-dashboard">
                        <!-- Dashboard Header -->
                        <div class="dashboard-header">
                            <h2>
                                <i class="fa fa-user"></i>
                                Welcome back, <?php echo htmlentities($patient['fullName']); ?>
                            </h2>
                            <div class="search-box">
                                <i class="fa fa-search"></i>
                                <input type="text" placeholder="Search appointments...">
                            </div>
                        </div>

                        <!-- Quick Stats -->
                        <div class="dashboard-stats">
                            <div class="stat-card">
                                <div class="stat-icon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <div class="stat-number"><?php echo $appointmentCount; ?></div>
                                <div class="stat-label">Total Appointments</div>
                            </div>

                            <div class="stat-card">
                                <div class="stat-icon">
                                    <i class="fa fa-check-circle"></i>
                                </div>
                                <div class="stat-number"><?php echo $confirmedCount; ?></div>
                                <div class="stat-label">Confirmed Appointments</div>
                            </div>

                            <div class="stat-card">
                                <div class="stat-icon">
                                    <i class="fa fa-clock-o"></i>
                                </div>
                                <div class="stat-number"><?php echo $pendingCount; ?></div>
                                <div class="stat-label">Pending Appointments</div>
                            </div>

                            <div class="stat-card">
                                <div class="stat-icon">
                                    <i class="fa fa-file-text"></i>
                                </div>
                                <div class="stat-number">0</div>
                                <div class="stat-label">Medical Records</div>
                            </div>
                        </div>

                        <!-- Recent Activity -->
                        <div class="dashboard-section">
                            <div class="section-title">
                                <i class="fa fa-history"></i>
                                Recent Activity
                            </div>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Activity</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = mysqli_query($con, "SELECT * FROM appointment WHERE patientId='$pid' ORDER BY appointmentDate DESC LIMIT 5");
                                        while($row = mysqli_fetch_array($query)) {
                                        ?>
                                        <tr>
                                            <td><?php echo htmlentities($row['appointmentDate']); ?></td>
                                            <td>Appointment with <?php echo htmlentities($row['doctorSpecialization']); ?></td>
                                            <td>
                                                <?php if($row['userStatus'] == 1) { ?>
                                                    <span class="status-badge status-confirmed">
                                                        <i class="fa fa-check"></i> Confirmed
                                                    </span>
                                                <?php } else { ?>
                                                    <span class="status-badge status-pending">
                                                        <i class="fa fa-clock-o"></i> Pending
                                                    </span>
                                                <?php } ?>
                                            </td>
                                            <td>
                                                <a href="view-appointment.php?viewid=<?php echo $row['id']; ?>" class="action-button">
                                                    <i class="fa fa-eye"></i> View Details
                                                </a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Quick Actions -->
                        <div class="dashboard-section">
                            <div class="section-title">
                                <i class="fa fa-bolt"></i>
                                Quick Actions
                            </div>
                            <div class="row">
                                <div class="col-sm-4">
                                    <a href="book-appointment.php" class="action-button">
                                        <i class="fa fa-plus"></i> Book New Appointment
                                    </a>
                                </div>
                                <div class="col-sm-4">
                                    <a href="medical-history.php" class="action-button">
                                        <i class="fa fa-file-text"></i> View Medical History
                                    </a>
                                </div>
                                <div class="col-sm-4">
                                    <a href="edit-profile.php" class="action-button">
                                        <i class="fa fa-user"></i> Update Profile
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/modernizr/modernizr.js"></script>
    <script src="vendor/jquery-cookie/jquery.cookie.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="vendor/switchery/switchery.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
        jQuery(document).ready(function() {
            Main.init();
        });
    </script>
</body>
</html>
<?php } ?> 