<?php
session_start();
//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>User | Dashboard</title>
		
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
		<link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
		<style>
			.dashboard-card {
				transition: all 0.3s ease;
				border-radius: 10px;
				box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
				margin-bottom: 20px;
				border: none;
			}
			.dashboard-card:hover {
				transform: translateY(-5px);
				box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
			}
			.dashboard-card .panel-body {
				padding: 25px;
			}
			.dashboard-card .fa-stack {
				margin-bottom: 15px;
			}
			.dashboard-card .StepTitle {
				font-size: 1.2em;
				margin-bottom: 15px;
				color: #2c3e50;
			}
			.dashboard-card .links a {
				color: #34495e;
				text-decoration: none;
				font-weight: 500;
				transition: color 0.3s ease;
			}
			.dashboard-card .links a:hover {
				color: #2c3e50;
			}
			.welcome-section {
				background: linear-gradient(135deg, #3498db 0%, #2c3e50 100%);
				color: white;
				padding: 30px;
				border-radius: 10px;
				margin-bottom: 30px;
			}
			.welcome-section h1 {
				font-size: 2.5em;
				margin-bottom: 10px;
			}
			.welcome-section p {
				font-size: 1.1em;
				opacity: 0.9;
			}
			.quick-stats {
				background: #f8f9fa;
				padding: 20px;
				border-radius: 10px;
				margin-bottom: 30px;
			}
			.stat-item {
				text-align: center;
				padding: 15px;
			}
			.stat-item .number {
				font-size: 2em;
				font-weight: bold;
				color: #34495e;
			}
			.stat-item .label {
				color: #7f8c8d;
				font-size: 0.9em;
			}
		</style>
	</head>
	<body>
		<div id="app">		
			<?php include('include/sidebar.php');?>
			<div class="app-content">
				<?php include('include/header.php');?>
				
				<div class="main-content">
					<div class="wrap-content container" id="container">
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Dashboard</h1>
								</div>
								<ol class="breadcrumb">
									<li>
										<span>User</span>
									</li>
									<li class="active">
										<span>Dashboard</span>
									</li>
								</ol>
							</div>
						</section>

						<div class="welcome-section">
							<h1>Welcome Back!</h1>
							<p>Manage your health and appointments efficiently</p>
						</div>

						<div class="quick-stats">
							<div class="row">
								<div class="col-md-4">
									<div class="stat-item">
										<div class="number">0</div>
										<div class="label">Upcoming Appointments</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="stat-item">
										<div class="number">0</div>
										<div class="label">Completed Appointments</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="stat-item">
										<div class="number">0</div>
										<div class="label">Pending Requests</div>
									</div>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-4">
								<div class="panel panel-white dashboard-card">
									<div class="panel-body text-center">
										<span class="fa-stack fa-2x"> 
											<i class="fa fa-square fa-stack-2x text-primary"></i> 
											<i class="fa fa-user-md fa-stack-1x fa-inverse"></i> 
										</span>
										<h2 class="StepTitle">My Profile</h2>
										<p class="links cl-effect-1">
											<a href="edit-profile.php">
												Update Profile
											</a>
										</p>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="panel panel-white dashboard-card">
									<div class="panel-body text-center">
										<span class="fa-stack fa-2x"> 
											<i class="fa fa-square fa-stack-2x text-primary"></i> 
											<i class="fa fa-calendar fa-stack-1x fa-inverse"></i> 
										</span>
										<h2 class="StepTitle">My Appointments</h2>
										<p class="links cl-effect-1">
											<a href="appointment-history.php">
												View Appointment History
											</a>
										</p>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="panel panel-white dashboard-card">
									<div class="panel-body text-center">
										<span class="fa-stack fa-2x"> 
											<i class="fa fa-square fa-stack-2x text-primary"></i> 
											<i class="fa fa-plus-circle fa-stack-1x fa-inverse"></i> 
										</span>
										<h2 class="StepTitle">Book Appointment</h2>
										<p class="links cl-effect-1">
											<a href="book-appointment.php">
												Schedule New Appointment
											</a>
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<?php include('include/footer.php');?>
			<?php include('include/setting.php');?>
		</div>

		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<script src="assets/js/main.js"></script>
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
	</body>
</html>
